package com.samarthshukla.gallery;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recycler;
    private final ArrayList<String> imagePaths = new ArrayList<>();
    private ActivityResultLauncher<String> permLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ✅ First initialize RecyclerView
        recycler = findViewById(R.id.recycler);
        recycler.setLayoutManager(new GridLayoutManager(this, 3));

        permLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                granted -> {
                    if (granted) loadImages();
                }
        );

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R
                && ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        } else {
            loadImages(); // ✅ Safe to call after recycler is initialized
        }
    }

    private void loadImages() {
        File dcim = new File(
                getExternalFilesDir(null).getParentFile(),
                "DCIM/Camera"
        );
        if (dcim.exists() && dcim.isDirectory()) {
            String[] files = dcim.list((dir, name) ->
                    name.endsWith(".jpg") || name.endsWith(".png")
            );
            if (files != null) {
                imagePaths.clear();
                for (String name : files) {
                    imagePaths.add(new File(dcim, name).getAbsolutePath());
                }
                Collections.reverse(imagePaths); // newest first
            }
        }

        ThumbnailAdapter thumbAdapter =
                new ThumbnailAdapter(this, imagePaths, pos -> {
                    Intent i = new Intent(this, PhotoViewActivity.class);
                    i.putStringArrayListExtra(
                            PhotoViewActivity.EXTRA_IMAGES,
                            imagePaths
                    );
                    i.putExtra(PhotoViewActivity.EXTRA_INDEX, pos);
                    startActivity(i);
                });
        recycler.setAdapter(thumbAdapter);
    }
}