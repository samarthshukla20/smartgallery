package com.samarthshukla.gallery;

import android.net.Uri;

public class MediaItem {
    private final Uri uri;
    private final boolean isVideo;
    private final long dateAdded;  // Add this field

    public MediaItem(Uri uri, boolean isVideo, long dateAdded) {
        this.uri = uri;
        this.isVideo = isVideo;
        this.dateAdded = dateAdded;
    }

    public Uri getUri() {
        return uri;
    }

    public boolean isVideo() {
        return isVideo;
    }

    public long getDateAdded() {
        return dateAdded;
    }
}