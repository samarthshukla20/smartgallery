package com.samarthshukla.gallery;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.ArrayList;
import java.util.List;

public class PhotoAdapter extends RecyclerView.Adapter<PhotoAdapter.PhotoViewHolder> {

    private final Context context;
    private final List<MediaItem> mediaItems;
    private final OnPhotoClickListener photoClickListener;

    public interface OnPhotoClickListener {
        void onPhotoClick(Uri uri, ImageView imageView, int position);
    }

    public PhotoAdapter(Context context, List<MediaItem> mediaItems, OnPhotoClickListener listener) {
        this.context = context;
        this.mediaItems = mediaItems;
        this.photoClickListener = listener;
    }

    @NonNull
    @Override
    public PhotoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_photo, parent, false);
        return new PhotoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PhotoViewHolder holder, int position) {
        MediaItem item = mediaItems.get(position);
        Uri uri = item.getUri();
        boolean isVideo = item.isVideo();

        // Load image thumbnail for both grid & overlay use
        Glide.with(context)
                .load(uri)
                .centerCrop()
                .thumbnail(0.8f) // show low-res quick preview
                .diskCacheStrategy(DiskCacheStrategy.ALL) // cache both thumb & original
                .into(holder.imageView);

        // Show video overlays
        holder.playIcon.setVisibility(isVideo ? View.VISIBLE : View.GONE);
        holder.videoOverlay.setVisibility(isVideo ? View.VISIBLE : View.GONE);

        // Set transition name for shared animation
        String transitionName = "media_" + position;
        ViewCompat.setTransitionName(holder.imageView, transitionName);

        holder.imageView.setOnClickListener(v -> {
            if (isVideo) {
                launchVideoPlayer(uri);
            } else if (photoClickListener != null) {
                photoClickListener.onPhotoClick(uri, holder.imageView, position);
            }
        });
    }

    private void launchVideoPlayer(Uri uri) {
        try {
            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
            String choice = prefs.getString("video_player_choice", null);

            Intent intent;
            if (choice == null) {
                intent = new Intent(context, VideoChoiceDialogActivity.class);
                intent.putExtra("video_uri", uri.toString());
            } else if ("in_app".equals(choice)) {
                intent = new Intent(context, VideoPlayerActivity.class);
                intent.putExtra(VideoPlayerActivity.EXTRA_VIDEO_URI, uri);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } else {
                intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(uri, "video/*");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }

            context.startActivity(intent);

        } catch (Exception e) {
            Toast.makeText(context, "Error opening video: " + e.getMessage(), Toast.LENGTH_LONG).show();
            Log.e("PhotoAdapter", "Error launching video player", e);
        }
    }

    @Override
    public int getItemCount() {
        return mediaItems.size();
    }

    static class PhotoViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        ImageView playIcon;
        View videoOverlay;

        public PhotoViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            playIcon = itemView.findViewById(R.id.playIcon);
            videoOverlay = itemView.findViewById(R.id.videoOverlay);
        }
    }
}