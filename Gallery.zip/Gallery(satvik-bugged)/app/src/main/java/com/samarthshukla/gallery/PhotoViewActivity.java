package com.samarthshukla.gallery;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.github.chrisbanes.photoview.PhotoView;

import java.io.File;
import java.util.ArrayList;

public class PhotoViewActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private LinearLayout actionPopup;
    private View selectionOverlay;
    private ImageButton deleteButton, shareButton;

    public static final String EXTRA_IMAGES = "extra_images";
    public static final String EXTRA_INDEX = "extra_index";
    
    private ArrayList<String> imagePaths;
    private int currentIndex;
    private boolean isSelected = false;

    private float startY = 0f;
    private final float SWIPE_THRESHOLD = 200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo_view);

        viewPager = findViewById(R.id.viewPager);
        actionPopup = findViewById(R.id.action_popup);
        selectionOverlay = findViewById(R.id.selection_overlay);
        deleteButton = findViewById(R.id.btn_delete);
        shareButton = findViewById(R.id.btn_share);

        imagePaths = getIntent().getStringArrayListExtra(EXTRA_IMAGES);
        currentIndex = getIntent().getIntExtra(EXTRA_INDEX, 0);

        PhotoViewerAdapter adapter = new PhotoViewerAdapter(this, imagePaths);
        viewPager.setAdapter(adapter);
        viewPager.setCurrentItem(currentIndex, false);

        // Touch gesture logic
        final GestureDetector gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {

            @Override
            public boolean onSingleTapConfirmed(@NonNull MotionEvent e) {
                // Could toggle UI visibility here
                return super.onSingleTapConfirmed(e);
            }

            @Override
            public void onLongPress(@NonNull MotionEvent e) {
                toggleSelection();
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                float deltaY = e2.getY() - e1.getY();
                if (Math.abs(deltaY) > SWIPE_THRESHOLD) {
                    if (deltaY > 0) {
                        // Swipe down to dismiss
                        finish();
                        overridePendingTransition(0, android.R.anim.fade_out);
                    } else {
                        // Swipe up to show info
                        showImageInfo();
                    }
                    return true;
                }
                return false;
            }
        });

        viewPager.getChildAt(0).setOnTouchListener((v, event) -> {
            gestureDetector.onTouchEvent(event);
            return false;
        });

        deleteButton.setOnClickListener(v -> {
            int position = viewPager.getCurrentItem();
            String imagePath = imagePaths.get(position);
            moveToRecycleBin(imagePath);
            imagePaths.remove(position);
            viewPager.getAdapter().notifyItemRemoved(position);
            toggleSelection();
        });

        shareButton.setOnClickListener(v -> {
            int position = viewPager.getCurrentItem();
            String imagePath = imagePaths.get(position);
            File imageFile = new File(imagePath);
            Uri uri = Uri.fromFile(imageFile);
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("image/*");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            startActivity(Intent.createChooser(share, "Share Image"));
        });
    }

    private void toggleSelection() {
        isSelected = !isSelected;
        selectionOverlay.setVisibility(isSelected ? View.VISIBLE : View.GONE);
        actionPopup.setVisibility(isSelected ? View.VISIBLE : View.GONE);

        if (isSelected) {
            actionPopup.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_up));
        } else {
            actionPopup.startAnimation(AnimationUtils.loadAnimation(this, R.anim.slide_down));
        }
    }

    private void showImageInfo() {
        int position = viewPager.getCurrentItem();
        String imagePath = imagePaths.get(position);
        Toast.makeText(this, "Image Path: " + imagePath, Toast.LENGTH_SHORT).show();
        // You can show a full info bottom sheet if needed.
    }

    private void moveToRecycleBin(String imagePath) {
        try {
            File sourceFile = new File(imagePath);
            File recycleBin = new File(Environment.getExternalStorageDirectory(), "RecycleBin");

            if (!recycleBin.exists()) {
                recycleBin.mkdirs();
            }

            File destFile = new File(recycleBin, sourceFile.getName());
            boolean success = sourceFile.renameTo(destFile);

            if (success) {
                Toast.makeText(this, "Moved to Recycle Bin", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed to delete", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
