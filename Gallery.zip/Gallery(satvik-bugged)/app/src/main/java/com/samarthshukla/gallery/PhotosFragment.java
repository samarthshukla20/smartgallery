package com.samarthshukla.gallery;

import android.Manifest;
import android.content.ContentUris;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.transition.Transition;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.target.Target;
import com.github.chrisbanes.photoview.PhotoView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PhotosFragment extends Fragment implements PhotoAdapter.OnPhotoClickListener {
    private RecyclerView recyclerView;
    private PhotoAdapter photoAdapter;
    private final List<MediaItem> mediaItems = new ArrayList<>();

    private ActivityResultLauncher<String> permissionLauncher;
    private ActivityResultLauncher<String[]> requestMultiplePermissions;

    private View overlayContainer;
    private PhotoView overlayPhotoView;
    private View bottomNavBar;

    private final Rect thumbnailBounds = new Rect();
    private float thumbnailScaleX;
    private float thumbnailScaleY;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_photos, container, false);

        recyclerView = view.findViewById(R.id.photosRecyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(requireContext(), 3));
        photoAdapter = new PhotoAdapter(requireContext(), mediaItems, this);
        recyclerView.setAdapter(photoAdapter);

        overlayContainer = view.findViewById(R.id.photoOverlayContainer);
        overlayPhotoView = view.findViewById(R.id.photoOverlayView);
        bottomNavBar = requireActivity().findViewById(R.id.bottomNav);

        view.findViewById(R.id.selectView)
                .setOnClickListener(v -> Toast.makeText(requireContext(), "Select clicked", Toast.LENGTH_SHORT).show());

        setupPermissions();
        setupBackPress();

        return view;
    }

    private void setupBackPress() {
        requireActivity().getOnBackPressedDispatcher().addCallback(getViewLifecycleOwner(),
                new OnBackPressedCallback(true) {
                    @Override
                    public void handleOnBackPressed() {
                        if (overlayContainer.getVisibility() == View.VISIBLE) {
                            closePhoto();
                        } else {
                            setEnabled(false);
                            requireActivity().onBackPressed();
                        }
                    }
                });
    }

    private void setupPermissions() {
        permissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
            if (isGranted)
                loadMedia();
            else
                Toast.makeText(requireContext(), "Permission denied", Toast.LENGTH_SHORT).show();
        });

        requestMultiplePermissions = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(),
                result -> {
                    boolean granted = result.getOrDefault(Manifest.permission.READ_MEDIA_IMAGES, false)
                            && result.getOrDefault(Manifest.permission.READ_MEDIA_VIDEO, false);
                    if (granted)
                        loadMedia();
                    else
                        Toast.makeText(requireContext(), "Permission denied", Toast.LENGTH_SHORT).show();
                });

        if (hasPermission())
            loadMedia();
        else
            requestPermission();
    }

    private boolean hasPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(requireContext(),
                    Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(requireContext(),
                            Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED;
        } else {
            return ContextCompat.checkSelfPermission(requireContext(),
                    Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
    }

    private void requestPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestMultiplePermissions.launch(new String[] {
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO
            });
        } else {
            permissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
    }

    private void loadMedia() {
        mediaItems.clear();
        mediaItems.addAll(fetchMedia(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false));
        mediaItems.addAll(fetchMedia(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true));
        Collections.sort(mediaItems, (a, b) -> Long.compare(b.getDateAdded(), a.getDateAdded()));
        photoAdapter.notifyDataSetChanged();
    }

    private List<MediaItem> fetchMedia(Uri collection, boolean isVideo) {
        List<MediaItem> items = new ArrayList<>();
        String[] projection = {
                MediaStore.MediaColumns._ID,
                MediaStore.MediaColumns.DATE_ADDED
        };
        String selection = MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?";
        String[] selectionArgs = new String[] { "%DCIM/Camera%" };
        String sortOrder = MediaStore.MediaColumns.DATE_ADDED + " DESC";

        try (Cursor cursor = requireContext().getContentResolver().query(
                collection, projection, selection, selectionArgs, sortOrder)) {
            if (cursor != null) {
                int idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID);
                int dateCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED);
                while (cursor.moveToNext()) {
                    long id = cursor.getLong(idCol);
                    long dateAdded = cursor.getLong(dateCol);
                    Uri contentUri = ContentUris.withAppendedId(collection, id);
                    items.add(new MediaItem(contentUri, isVideo, dateAdded));
                }
            }
        }
        return items;
    }

    @Override
    public void onPhotoClick(Uri uri, ImageView imageView, int position) {
        if (bottomNavBar != null)
            bottomNavBar.setVisibility(View.GONE);

        int[] screenPos = new int[2];
        imageView.getLocationOnScreen(screenPos);
        thumbnailBounds.set(
                screenPos[0],
                screenPos[1],
                screenPos[0] + imageView.getWidth(),
                screenPos[1] + imageView.getHeight());

        overlayPhotoView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        overlayPhotoView.setImageDrawable(imageView.getDrawable());
        overlayPhotoView.setTranslationX(thumbnailBounds.left);
        overlayPhotoView.setTranslationY(thumbnailBounds.top);
        overlayPhotoView.setPivotX(0);
        overlayPhotoView.setPivotY(0);

        overlayContainer.setAlpha(0f);
        overlayContainer.setVisibility(View.VISIBLE);
        overlayContainer.animate().alpha(1f).setDuration(180).start();

        overlayPhotoView.post(() -> {
            int overlayW = overlayPhotoView.getWidth();
            int overlayH = overlayPhotoView.getHeight();

            thumbnailScaleX = (float) imageView.getWidth() / overlayW;
            thumbnailScaleY = (float) imageView.getHeight() / overlayH;

            overlayPhotoView.setScaleX(thumbnailScaleX);
            overlayPhotoView.setScaleY(thumbnailScaleY);
            overlayPhotoView.setClickable(false);

            overlayPhotoView.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .translationX(0f)
                    .translationY(0f)
                    .setDuration(300)
                    .setInterpolator(new AccelerateDecelerateInterpolator())
                    .withEndAction(() -> {
                        try {
                            Glide.with(requireContext())
                                    .load(uri)
                                    .apply(new RequestOptions()
                                            .override(overlayW, overlayH)
                                            .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                                            .dontAnimate()
                                            .centerInside())
                                    .into(new CustomTarget<Drawable>() {
                                        @Override
                                        public void onResourceReady(@NonNull Drawable resource,
                                                Transition<? super Drawable> transition) {
                                            overlayPhotoView.setImageDrawable(resource);
                                            overlayPhotoView.setClickable(true);
                                        }

                                        @Override
                                        public void onLoadCleared(Drawable placeholder) {
                                        }
                                    });
                        } catch (Exception e) {
                            Toast.makeText(requireContext(), "Image too large", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .start();
        });

        overlayPhotoView.setOnClickListener(v -> closePhoto());
    }

    private void closePhoto() {
        overlayPhotoView.setClickable(false);
        overlayPhotoView.animate()
                .scaleX(thumbnailScaleX)
                .scaleY(thumbnailScaleY)
                .translationX(thumbnailBounds.left)
                .translationY(thumbnailBounds.top)
                .setDuration(280)
                .setInterpolator(new AccelerateDecelerateInterpolator())
                .withEndAction(() -> {
                    Glide.with(requireContext()).clear(overlayPhotoView);
                    overlayPhotoView.setImageDrawable(null);
                    overlayPhotoView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    overlayContainer.setVisibility(View.GONE);
                    if (bottomNavBar != null)
                        bottomNavBar.setVisibility(View.VISIBLE);
                    overlayPhotoView.setClickable(true);
                })
                .start();
    }

}