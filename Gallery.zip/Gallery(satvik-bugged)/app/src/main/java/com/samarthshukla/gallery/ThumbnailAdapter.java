package com.samarthshukla.gallery;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.io.File;
import java.util.List;

public class ThumbnailAdapter
        extends RecyclerView.Adapter<ThumbnailAdapter.VH> {

    public interface OnClick { void onClick(int pos); }

    private final Context ctx;
    private final List<String> images;
    private final OnClick listener;

    public ThumbnailAdapter(
            Context ctx, List<String> images, OnClick listener
    ) {
        this.ctx      = ctx;
        this.images   = images;
        this.listener = listener;
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int v) {
        View vew = LayoutInflater.from(ctx)
                .inflate(R.layout.item_thumbnail, p, false);
        return new VH(vew);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        String path = images.get(pos);
        Glide.with(ctx)
                .load(path)
                .centerCrop()
                .into(h.thumb);
        h.itemView.setOnClickListener(v -> listener.onClick(pos));
    }

    @Override public int getItemCount() { return images.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final ImageView thumb;
        VH(View v) {
            super(v);
            thumb = v.findViewById(R.id.thumb);
        }
    }
}
